# blood cell detection > 2023-10-05 5:27pm
https://universe.roboflow.com/clg-vtj9f/blood-cell-detection-bsbvn

Provided by a Roboflow user
License: CC BY 4.0

